from django.apps import AppConfig


class CivamConfig(AppConfig):
    name = 'civam'
